package SyntaxAnalyse.SyntaxTreeNodes;

import LexicalAnalyse.LexicalType;
import LexicalAnalyse.Word;

public class BType {
    static final String terminal = "int";
}
