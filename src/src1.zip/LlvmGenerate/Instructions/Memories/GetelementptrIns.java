package LlvmGenerate.Instructions.Memories;

import LlvmGenerate.BasicBlock;
import LlvmGenerate.Instructions.Instruction;
import LlvmGenerate.Operand;
import LlvmGenerate.Types.Type;

import java.util.ArrayList;

public class GetelementptrIns extends Instruction {
    public GetelementptrIns(String regName, BasicBlock basicBlock, ArrayList<Operand> operandList, Type type) {
        super(basicBlock);
    }
}
