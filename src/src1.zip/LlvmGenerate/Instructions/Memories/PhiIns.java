package LlvmGenerate.Instructions.Memories;

import LlvmGenerate.BasicBlock;
import LlvmGenerate.Instructions.Instruction;
import LlvmGenerate.Operand;
import LlvmGenerate.Types.Type;

import java.util.ArrayList;

public class PhiIns extends Instruction {
    public PhiIns(String regName, BasicBlock basicBlock, ArrayList<Operand> operandList, Type type) {
        super(basicBlock);
    }
}
