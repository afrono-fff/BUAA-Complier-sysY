package LlvmGenerate.Instructions.Memories;

import LlvmGenerate.BasicBlock;
import LlvmGenerate.Instructions.Instruction;
import LlvmGenerate.Operand;
import LlvmGenerate.Registers.Register;
import LlvmGenerate.Types.Type;

import java.util.ArrayList;

public class ZextToIns extends Instruction {
    public ZextToIns(String regName, BasicBlock basicBlock, ArrayList<Operand> operandList, Type type) {
        super(basicBlock);
    }
}
