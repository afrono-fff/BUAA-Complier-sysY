package LlvmGenerate.Instructions.Memories;

import LlvmGenerate.BasicBlock;
import LlvmGenerate.Instructions.Instruction;
import LlvmGenerate.Operand;
import LlvmGenerate.Types.Type;

import javax.xml.namespace.QName;
import java.util.ArrayList;

public class AllocaIns extends Instruction {
    private String name;
    private String type;
    public AllocaIns(BasicBlock basicBlock, String name, String type) {
        super(basicBlock);
        this.name = name;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return this.name + " = alloca " + this.type;
    }
}
