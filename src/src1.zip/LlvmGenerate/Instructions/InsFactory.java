package LlvmGenerate.Instructions;

import LlvmGenerate.BasicBlock;
import LlvmGenerate.Instructions.Calculations.*;
import LlvmGenerate.Instructions.Definations.Const;
import LlvmGenerate.Instructions.Definations.Function;
import LlvmGenerate.Instructions.Definations.GlobalDecl;
import LlvmGenerate.Instructions.Definations.Parameter;
import LlvmGenerate.Instructions.Jump.CallIns;
import LlvmGenerate.Instructions.Jump.RetIns;
import LlvmGenerate.Instructions.Memories.AllocaIns;
import LlvmGenerate.Instructions.Memories.LoadIns;
import LlvmGenerate.Instructions.Memories.StoreIns;
import LlvmGenerate.MiddleVal;
import LlvmGenerate.Operand;
import LlvmGenerate.Registers.RegisterPool;
import SymbolTable.VarSymbol;

import javax.swing.plaf.IconUIResource;
import java.util.ArrayList;

public class InsFactory {
    RegisterPool registerPool;
    public InsFactory(){
        this.registerPool = new RegisterPool();
    }
    public AddIns generateAdd(BasicBlock basicBlock, MiddleVal L, MiddleVal R){
        String regName = registerPool.distributeRegister(); // 分配寄存器
        AddIns addIns = new AddIns(basicBlock, regName, "i32", L.toString(), R.toString());
        basicBlock.addIns(addIns);
        return addIns;
    }
    public SubIns generateSub(BasicBlock basicBlock, MiddleVal L, MiddleVal R){
        String regName = registerPool.distributeRegister(); // 分配寄存器
        SubIns subIns = new SubIns(basicBlock, regName, "i32", L.toString(), R.toString());
        basicBlock.addIns(subIns);
        return subIns;
    }
    public MulIns generateMul(BasicBlock basicBlock, MiddleVal L, MiddleVal R){
        String regName = registerPool.distributeRegister(); // 分配寄存器
        MulIns mulIns = new MulIns(basicBlock, regName, "i32", L.toString(), R.toString());
        basicBlock.addIns(mulIns);
        return mulIns;
    }
    public SdivIns generateSdiv(BasicBlock basicBlock, MiddleVal L, MiddleVal R){
        String regName = registerPool.distributeRegister(); // 分配寄存器
        SdivIns sdivIns = new SdivIns(basicBlock, regName, "i32", L.toString(), R.toString());
        basicBlock.addIns(sdivIns);
        return sdivIns;
    }
    public SremIns generateSrem(BasicBlock basicBlock, MiddleVal L, MiddleVal R){
        String regName = registerPool.distributeRegister(); // 分配寄存器
        SremIns sremIns = new SremIns(basicBlock, regName, "i32", L.toString(), R.toString());
        basicBlock.addIns(sremIns);
        return sremIns;
    }
    public Function generateFunction(String name, String retType, ArrayList<Parameter> parameterList, ArrayList<BasicBlock> basicBlockList){
        Function function = new Function(name, retType, parameterList, basicBlockList);
        return function;
    }
    public RetIns generateRetVoid(BasicBlock basicBlock){
        RetIns retIns = new RetIns(basicBlock);
        basicBlock.addIns(retIns);
        return retIns;
    }
    public RetIns generateRetWithExp(BasicBlock basicBlock, String retType, MiddleVal retVal){
        RetIns retIns = new RetIns(basicBlock, retType, retVal);
        basicBlock.addIns(retIns);
        return retIns;
    }
    public GlobalDecl generateGlobalDecl(VarSymbol declSymbol){
        String name = declSymbol.getToken();
        int dimension = declSymbol.getDimension();
        String type;
        if(dimension == 0){
            type = "i32";
        }else if(dimension == 1){
            type = "i32*";
        }else{
            type = "i32**";
        }
        MiddleVal value = declSymbol.getValue();
        GlobalDecl globalDecl = new GlobalDecl(name, type, value, declSymbol.varIsConst());
        return globalDecl;
    }
    public AllocaIns generateAlloca(BasicBlock basicBlock, String type){
        String name = registerPool.distributeRegister();
        AllocaIns allocaIns = new AllocaIns(basicBlock, name, type);
        basicBlock.addIns(allocaIns);
        return allocaIns;
    }
    public StoreIns generateStore(BasicBlock basicBlock, String vt, String vv, String at, String av){
        StoreIns storeIns = new StoreIns(basicBlock, vt, vv, at, av);
        basicBlock.addIns(storeIns);
        return storeIns;
    }
    public LoadIns generateLoad(BasicBlock basicBlock, String vt, String at, String av){
        String regName = registerPool.distributeRegister();
        LoadIns loadIns = new LoadIns(basicBlock, regName, vt, at, av);
        basicBlock.addIns(loadIns);
        return loadIns;
    }
    public CallIns generateCall(BasicBlock basicBlock, String retType, String funPtr, ArrayList<Parameter> parameterList){
        if(retType.equals("void")){ // 无返回函数
            CallIns callIns = new CallIns(basicBlock, true, funPtr, null, "void", parameterList);
            basicBlock.addIns(callIns);
            return callIns;
        }else{ // 有返回
            String regName = registerPool.distributeRegister();
            CallIns callIns = new CallIns(basicBlock, false, funPtr, regName, retType, parameterList);
            basicBlock.addIns(callIns);
            return callIns;
        }
    }
    public String getParameterRegister(){
        return registerPool.distributeRegister();
    }
}
