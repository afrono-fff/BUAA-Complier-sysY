package LlvmGenerate.Instructions;

import LlvmGenerate.BasicBlock;
import LlvmGenerate.Operand;
import LlvmGenerate.Registers.Register;
import LlvmGenerate.Types.Type;

import java.util.ArrayList;

public class Instruction {
    BasicBlock basicBlock;
    public Instruction(BasicBlock basicBlock){
        this.basicBlock = basicBlock;
    }
}
