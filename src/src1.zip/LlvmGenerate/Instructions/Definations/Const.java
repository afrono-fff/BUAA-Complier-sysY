package LlvmGenerate.Instructions.Definations;

public class Const {
    private String name;
    private String type;
    private int constValue;
    private boolean isGlobal; // 是否为全局
    public Const(String name, String type, int constValue, boolean isGlobal){
        this.name = name;
        this.type = type;
        this.constValue = constValue;
        this.isGlobal = isGlobal;
    }

    @Override
    public String toString() {
        if(isGlobal){
            return this.name + " = const " + this.type + " " + this.constValue;
        }else{
            return "";
        }
    }
}
