package LlvmGenerate.Instructions.Definations;

import LlvmGenerate.MiddleVal;

public class GlobalDecl {
    private String name;
    private String valueType; // 数值类型
    private MiddleVal v_r; // 数值或寄存器
    private boolean isConst;
    public GlobalDecl(String name, String valueType, MiddleVal v_r, boolean isConst){
        this.name = name;
        this.valueType = valueType;
        this.v_r = v_r;
        this.isConst = isConst;
    }

    @Override
    public String toString() {
        String v_c = isConst?"constant":"global";
        if(valueType.equals("i32")){ // 普通变量
            return "@" + this.name + " = "+ v_c + " " + this.valueType + " " + this.v_r.getIntCon();
        }
        return "TODO!";
    }
}
