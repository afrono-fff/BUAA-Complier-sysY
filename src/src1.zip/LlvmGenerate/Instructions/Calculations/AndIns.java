package LlvmGenerate.Instructions.Calculations;

import LlvmGenerate.BasicBlock;
import LlvmGenerate.Instructions.Instruction;
import LlvmGenerate.Operand;
import LlvmGenerate.Types.Type;

import java.util.ArrayList;

public class AndIns extends Instruction {
    public AndIns(String regName, BasicBlock basicBlock, ArrayList<Operand> operandList, Type type) {
        super(basicBlock);
    }
}
