package LlvmGenerate.Instructions.Jump;

import LlvmGenerate.BasicBlock;
import LlvmGenerate.Instructions.Instruction;
import LlvmGenerate.Operand;
import LlvmGenerate.Types.Type;

import java.util.ArrayList;

public class BrIns extends Instruction {
    public BrIns(String regName, BasicBlock basicBlock, ArrayList<Operand> operandList, Type type) {
        super(basicBlock);
    }
}
