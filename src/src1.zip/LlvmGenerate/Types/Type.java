package LlvmGenerate.Types;

public class Type {
    private String type;
}
