package LlvmGenerate.Types;

public class VarType extends Type{

}
