package LlvmGenerate;

import LlvmGenerate.Instructions.Instruction;

import java.util.ArrayList;

public class BasicBlock {
    ArrayList<Instruction> instructionList;
    public BasicBlock(){
        this.instructionList = new ArrayList<>();
    }
    public void addIns(Instruction instruction){
        this.instructionList.add(instruction);
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        for(Instruction instruction: instructionList){
            str.append("\t").append(instruction.toString()).append("\n");
        }
        return str.toString();
    }
}
