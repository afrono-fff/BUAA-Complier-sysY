package LlvmGenerate;

import ErrorHandle.ErrorType;
import LexicalAnalyse.LexicalType;
import LexicalAnalyse.Number;
import LexicalAnalyse.Word;
import LlvmGenerate.Instructions.Calculations.*;
import LlvmGenerate.Instructions.Definations.Const;
import LlvmGenerate.Instructions.Definations.Function;
import LlvmGenerate.Instructions.Definations.GlobalDecl;
import LlvmGenerate.Instructions.Definations.Parameter;
import LlvmGenerate.Instructions.InsFactory;
import LlvmGenerate.Instructions.Jump.CallIns;
import LlvmGenerate.Instructions.LlvmTree;
import LlvmGenerate.Instructions.Memories.AllocaIns;
import LlvmGenerate.Instructions.Memories.LoadIns;
import SymbolTable.FuncSymbol;
import SymbolTable.Symbol;
import SymbolTable.SymbolTable;
import SymbolTable.VarSymbol;
import SyntaxAnalyse.SyntaxAnalyzer;
import SyntaxAnalyse.SyntaxTreeNodes.*;
import com.sun.tools.javac.Main;

import java.util.ArrayList;

public class LlvmGenerator {
    private SyntaxAnalyzer SA;
    private SymbolTable symTab;
    private ArrayList<BasicBlock> curBasicBlockList;
    private BasicBlock curBasicBlock;
    private LlvmTree out; // 生成的llvm文件
    private InsFactory insFactory;
    private ArrayList<FuncFParam> curFuncFParamList; // 当前函数形参表
    private boolean isGlobalDecl;
    private MiddleVal middleVal;
    public LlvmGenerator(SyntaxAnalyzer SA){
        this.SA = SA;
        this.symTab = new SymbolTable();
        this.curBasicBlockList = new ArrayList<>();
        curBasicBlock = new BasicBlock();
        this.out = new LlvmTree();
        this.insFactory = new InsFactory();
        this.curFuncFParamList = null;
        isGlobalDecl = false;
        middleVal = new MiddleVal();
    }
    public void traverse(){
        CompUnitRec(SA.getRoot());
        System.out.println(out);
    }
    public void CompUnitRec(CompUnit compUnit){
        ArrayList<Decl> declList = compUnit.getDeclList();
        ArrayList<FuncDef> funcDefList = compUnit.getFuncDefList();
        MainFuncDef mainFuncDef = compUnit.getMainFuncDef();
        for(Decl decl: declList){
            isGlobalDecl = true;
            declRec(decl);
            isGlobalDecl = false;
        }
        for(FuncDef funcDef: funcDefList){
            funcDefRec(funcDef);
        }
        mainFuncDefRec(mainFuncDef);
    }

    private void declRec(Decl decl){
        // Decl不输出：直接区分ConstDecl和VarDecl
        ConstDecl constDecl = decl.getConstDecl();
        VarDecl varDecl = decl.getVarDecl();
        if(constDecl != null){
            // 常量声明
            constDeclRec(constDecl);
        }else{
            // 变量声明
            varDeclRec(varDecl);
        }
    }
    private void constDeclRec(ConstDecl constDecl){ // constDecl递归子程序
        // ConstDecl → 'const' BType ConstDef { ',' ConstDef } ';'
        BType bType = constDecl.getbType();
        ArrayList<ConstDef> constDefList = constDecl.getConstDefList();
        for(ConstDef constDef: constDefList){
            constDefRec(constDef);
        }
    }
    private void bTypeRec(){
        // BType → 'int'

    }
    private void constDefRec(ConstDef constDef){ // constDef递归子程序
        // ConstDef → Ident { '[' ConstExp ']' } '=' ConstInitVal
        Word ident = constDef.getIdent();
        ArrayList<ConstExp> constExpList = constDef.getConstExpList();
        ConstInitVal constInitVal = constDef.getConstInitVal();

        if(constExpList.isEmpty()){ // 普通变量
            //填符号表
            constInitValRec(constInitVal);
            VarSymbol vs = declareVar(ident.getToken(), 0, new ArrayList<>(), true, middleVal.copy());
            if(isGlobalDecl){
                GlobalDecl globalDecl = insFactory.generateGlobalDecl(vs);
                out.addGlobalDecl(globalDecl);
            }else {
                // 局部

            }
        }else{ // 数组

        }

    }
    private void constExpRec(ConstExp constExp){ // constExp递归子程序
        //  ConstExp → AddExp
        AddExp addExp = constExp.getAddExp();
        addExpRec(addExp);
    }
    private void addExpRec(AddExp addExp){ // addExp子程序
        // AddExp → MulExp { ('+' | '−') MulExp }
        ArrayList<MulExp> mulExpList = addExp.getMulExpList();
        ArrayList<String> opList = addExp.getOpList();
        int entryNum = mulExpList.size(); // 加减表达式的项数

        if(entryNum == 1){ // 一项，即mulExp
            mulExpRec(mulExpList.get(0));
        }else {
            MulExp mulExp1 = mulExpList.get(0);
            mulExpRec(mulExp1);
            MiddleVal L = middleVal.copy();
            for(int i = 1; i < entryNum; i++){
                MulExp mulExp_r = mulExpList.get(i);
                mulExpRec(mulExp_r);
                MiddleVal R = middleVal.copy();
                String op = opList.get(i - 1);
                if(op.equals("plus")){ // add
                    if(isGlobalDecl){
                        middleVal.setIntCon(L.getIntCon() + R.getIntCon());
                    }else{
                        AddIns addIns = insFactory.generateAdd(curBasicBlock, L, R);
                        middleVal.setRegister(addIns.getRegName());
                    }
                }else{ // "minu" sub
                    if(isGlobalDecl){
                        middleVal.setIntCon(L.getIntCon() - R.getIntCon());
                    }else{
                        SubIns subIns = insFactory.generateSub(curBasicBlock, L, R);
                        middleVal.setRegister(subIns.getRegName());
                    }
                }
                L = middleVal.copy();
            }
        }
    }
    private void mulExpRec(MulExp mulExp){
        // MulExp → UnaryExp { ('*' | '/' | '%') UnaryExp }
        ArrayList<UnaryExp> unaryExpList = mulExp.getUnaryExpList();
        ArrayList<String> opList = mulExp.getOpList();
        int entryNum = unaryExpList.size(); // 乘除模表达式的项数

        if(entryNum == 1){ // 一项，即unaryExp
            unaryExpRec(unaryExpList.get(0));
        }else {
            UnaryExp unaryExp1 = unaryExpList.get(0);
            unaryExpRec(unaryExp1);
            MiddleVal L = middleVal.copy();
            for(int i = 1; i < entryNum; i++){
                UnaryExp unaryExp_r = unaryExpList.get(i);
                unaryExpRec(unaryExp_r);
                MiddleVal R = middleVal.copy();
                String op = opList.get(i - 1);
                if(op.equals("mult")){ // mul
                    if(isGlobalDecl){
                        middleVal.setIntCon(L.getIntCon() * R.getIntCon());
                    }else{
                        MulIns mulIns = insFactory.generateMul(curBasicBlock, L, R);
                        middleVal.setRegister(mulIns.getRegName());
                    }
                }else if(op.equals("div")){ // sdiv
                    if(isGlobalDecl){
                        middleVal.setIntCon(L.getIntCon() / R.getIntCon());
                    }else{
                        SdivIns sdivIns = insFactory.generateSdiv(curBasicBlock, L, R);
                        middleVal.setRegister(sdivIns.getRegName());
                    }
                }else{ // "mod" srem
                    if(isGlobalDecl){
                        middleVal.setIntCon(L.getIntCon() % R.getIntCon());
                    }else{
                        SremIns sremIns = insFactory.generateSrem(curBasicBlock, L, R);
                        middleVal.setRegister(sremIns.getRegName());
                    }
                }
                L = middleVal.copy();
            }
        }
    }
    private void unaryExpRec(UnaryExp unaryExp){
        // UnaryExp → PrimaryExp | Ident '(' [FuncRParams] ')' | UnaryOp UnaryExp
        PrimaryExp primaryExp = unaryExp.getPrimaryExp();
        Word ident = unaryExp.getIdent();
        FuncRParams funcRParams = unaryExp.getFuncRParams();
        UnaryExp unaryExp1 = unaryExp.getUnaryExp();
        UnaryOp unaryOp = unaryExp.getUnaryOp();

        if(unaryExp.getUnaryExpType().equals("primary")){ // 数字、括号、变量名等
            primaryExpRec(primaryExp);
        }else if(unaryExp.getUnaryExpType().equals("call")){ // 函数调用
            if(ident.getToken().equals("@getint")){ // 表达式调用库函数getint()
                CallIns callIns = insFactory.generateCall(curBasicBlock, "i32", "@getint", new ArrayList<>());
                middleVal.setRegister(callIns.getRegName());
            }else{ // 自定义的函数

            }
        }else{ // "signed" 一元运算符
            unaryExpRec(unaryExp1);
            MiddleVal R = middleVal.copy();
            if(unaryOp.getTerminal().getType() == LexicalType.MINU){ // 负号，相当于用0减
                MiddleVal zero = new MiddleVal("intConst", 0, null, null);
                if(isGlobalDecl){
                    middleVal.setIntCon(-R.getIntCon());
                }else{
                    SubIns subIns = insFactory.generateSub(curBasicBlock, zero, R);
                    middleVal.setRegister(subIns.getRegName());
                }
            }
        }
    }
    private void unaryOpRec(){
        // UnaryOp → '+' | '−' | '!'

    }
    private void funcRParamsRec(){
        //  FuncRParams → Exp { ',' Exp }

    }
    private void expRec(Exp exp){
        //  Exp → AddExp
        AddExp addExp = exp.getAddExp();
        addExpRec(addExp);
    }
    private void primaryExpRec(PrimaryExp primaryExp){
        // PrimaryExp → '(' Exp ')' | LVal | Number
        Exp exp = primaryExp.getExp();
        LVal lVal= primaryExp.getlVal();
        Number number = primaryExp.getNumber();
        if(exp != null){ // 第一种
            expRec(exp);
        }else if(lVal != null){ // 第二种
            lValRec(lVal);
        }else{ // 第三种：数字
            middleVal.setType("intConst");
            middleVal.setIntCon(number.getNumber());
        }
    }
    private void lValRec(LVal lVal){
        //  LVal → Ident {'[' Exp ']'}
        Word ident = lVal.getIdent();
        ArrayList<Exp> expList = lVal.getExpList();
        VarSymbol vs = (VarSymbol) searchSymbol(ident.getToken());
        int dimension = vs.getDimension() - expList.size();
        if(dimension == 0){ // 此时数据类型为"i32"（普通变量，或一维数组a[n],或二维数组b[m][n]）
            if(vs.getStoreReg() != null){
                // 需要通过load取变量
                LoadIns loadIns = insFactory.generateLoad(curBasicBlock, "i32", "i32*", vs.getStoreReg());
                vs.setValue(new MiddleVal("register", 0, loadIns.getName(), null));
                middleVal.setRegister(loadIns.getName());
            }else{
                middleVal = vs.getValue().copy();
            }
        }
    }
    private void constInitValRec(ConstInitVal constInitVal){ // constInitVal子程序
        // ConstInitVal → ConstExp | '{' [ ConstInitVal { ',' ConstInitVal } ] '}'
        ConstExp constExp = constInitVal.getConstExp();
        ArrayList<ConstInitVal> constInitValList = constInitVal.getConstInitValList();
        if(constInitValList == null){ // 普通变量
            constExpRec(constExp);
        }else{ // 数组

        }
    }
    private void varDeclRec(VarDecl varDecl){ // VarDecl递归子程序
        //  VarDecl → BType VarDef { ',' VarDef } ';'
        ArrayList<VarDef> varDefList = varDecl.getVarDefList();
        for(VarDef varDef: varDefList){
            varDefRec(varDef);
        }
    }
    private void varDefRec(VarDef varDef){
        // VarDef  → Ident { '[' ConstExp ']' } ( # | '=' InitVal) #表示空串
        Word ident = varDef.getIdent();
        ArrayList<ConstExp> constExpList = varDef.getConstExpList();
        InitVal initVal = varDef.getInitVal();
        if(constExpList.isEmpty()){ // 普通变量
            if(isGlobalDecl){ // 全局
                if(initVal != null){ // 有初始值
                    initValRec(initVal);
                }else{
                    middleVal.setIntCon(0); // 全局变量初始化为0
                }
                VarSymbol vs = declareVar(ident.getToken(), 0, new ArrayList<>(), false, middleVal.copy());
                out.addGlobalDecl(insFactory.generateGlobalDecl(vs));
            }else{ // 局部
                AllocaIns allocaIns = insFactory.generateAlloca(curBasicBlock, "i32");
                String allocaReg = allocaIns.getName(); // 存储空间的寄存器名
                if(initVal != null){ // 有初始值
                    initValRec(initVal);
                }else{
                    middleVal.setIntCon(0); //
                }
                VarSymbol vs = declareVar(ident.getToken(), 0, new ArrayList<>(), false, middleVal.copy());
                insFactory.generateStore(curBasicBlock, "i32", middleVal.toString(),"i32*" , allocaReg);
                // store命令在val和addr之间建立了索引关系,下次访问val时生成load命令
                vs.setStoreReg(allocaReg);
            }
        }else{ // 数组

        }
    }
    private void initValRec(InitVal initVal){
        // InitVal → Exp | '{' [ InitVal { ',' InitVal } ] '}'
        Exp exp = initVal.getExp();
        ArrayList<InitVal> initValList = initVal.getInitValList();
        if(initValList == null){ // 普通变量
            expRec(exp);
        }else{ // 数组

        }
    }
    private void funcDefRec(FuncDef funcDef){
        //  FuncDef → FuncType Ident '(' [FuncFParams] ')' Block
        FuncType funcType = funcDef.getFuncType();
        Word ident = funcDef.getIdent();
        FuncFParams funcFParams = funcDef.getFuncFParams();
        Block block = funcDef.getBlock();
        declareFunc(ident.getToken(), !funcType.isInt(), funcFParams.getParamNum(), funcFParams.getDimensions());
        curBasicBlock = new BasicBlock(); // 函数起始：新的基本块
        curBasicBlockList.add(curBasicBlock); // 初始为空，函数建立完成后也要清空为下一个函数做准备
        funcFParamsRec(funcFParams); // 递归访问参数表，为每个参数分配寄存器
        ArrayList<Parameter> parameterList = new ArrayList<>();
        for(FuncFParam funcFParam: curFuncFParamList){
            int dimension = funcFParam.getDimension();
            String type = new String();
            if(dimension == 0){
                type = "i32";
            }else if(dimension == 1){
                type = "i32*";
            }else if(dimension == 2){
                type = "i32**";
            }
            Parameter parameter = new Parameter(type, funcFParam.getValue());
            parameterList.add(parameter);
        }
        blockRec(block); // 递归访问函数体block，建立相应基本块
        String retType = funcType.isInt()?"i32":"void";
        Function function = new Function(ident.getToken(), retType, parameterList, curBasicBlockList);
        out.addFunction(function);
        curBasicBlockList.clear();
    }
    private void funcTypeRec(){
        // FuncType → 'void' | 'int'

    }
    private void blockRec(Block block){
        // Block → '{' { BlockItem } '}'
        createSymTab(); // 创建符号表
        if(curFuncFParamList != null){
            // 表示此时block为函数block，需要将curFuncFParams填符号表
            for(FuncFParam ffp:curFuncFParamList){
                // TODO:ArrayList length
                declareVar(ffp.getIdent().getToken(), ffp.getDimension(), new ArrayList<>(), false,new MiddleVal());
            }
        }

        ArrayList<BlockItem> blockItemList = block.getBlockItemList();
        for(BlockItem blockItem: blockItemList){
            blockItemRec(blockItem);
        }
        exitSymTab();
    }
    private void blockItemRec(BlockItem blockItem){
        // BlockItem → Decl | Stmt
        Decl decl = blockItem.getDecl();
        Stmt stmt = blockItem.getStmt();
        if(decl != null){
            declRec(decl);
        }else{
            stmtRec(stmt);
        }
    }
    private void stmtRec(Stmt stmt){
        /* Stmt → LVal '=' Exp ';'
            | [Exp] ';'
            | Block
            | 'if' '(' Cond ')' Stmt [ 'else' Stmt ]
            | 'for' '(' [ForStmt] ';' [Cond] ';' [ForStmt] ')' Stmt
            | 'break' ';'
            | 'continue' ';'
            | 'return' [Exp] ';'
            | LVal '=' 'getint''('')'';'
            | 'printf''('FormatString{','Exp}')'';'
        */
        LVal lVal;
        Exp exp;
        Block block;
        Cond cond;
        Stmt _stmt;
        Stmt elseStmt;
        ForStmt forStmt1;
        ForStmt forStmt2;
        Word forTerminal;
        Word formatString;
        ArrayList<Exp> expList = new ArrayList<>();
        if(stmt.getStmtType().equals("returnWithExp")){
            exp = stmt.getExp();
            expRec(exp);
            insFactory.generateRetWithExp(curBasicBlock,"i32",middleVal.copy());
        }else if(stmt.getStmtType().equals("returnVoid")){
            insFactory.generateRetVoid(curBasicBlock);
        }else if(stmt.getStmtType().equals("block")){
            block = stmt.getBlock();
            blockRec(block);
        }else if(stmt.getStmtType().equals("assign")){
            lVal = stmt.getlVal();
            exp = stmt.getExp();
            VarSymbol vs = (VarSymbol) searchSymbol(lVal.getIdent().getToken());
            String storeRegName = vs.getStoreReg();
            expRec(exp);
            insFactory.generateStore(curBasicBlock, "i32", middleVal.toString(), "i32*", storeRegName);
            vs.setStoreReg(storeRegName); // 注：每次store都要更新变量符号的存储寄存器！（这里可以不更新，因为取了原寄存器）
        }else if(stmt.getStmtType().equals("assign_getint")){
            lVal = stmt.getlVal();
            VarSymbol vs = (VarSymbol) searchSymbol(lVal.getIdent().getToken());
            String storeRegName = vs.getStoreReg();
            CallIns callIns = insFactory.generateCall(curBasicBlock, "i32", "@getint", new ArrayList<>());
            middleVal.setRegister(callIns.getRegName());
            insFactory.generateStore(curBasicBlock, "i32", middleVal.getRegister(), "i32*", storeRegName);
            vs.setStoreReg(storeRegName);
        }else if(stmt.getStmtType().equals("printf")){
            formatString = stmt.getFormatString();
            expList = stmt.getExpList();
            int expIndex = 0;
            char[] charArray = formatString.getToken().toCharArray();
            for(int i = 0; i < formatString.getToken().length(); i ++ ){
                if(charArray[i] == '"'){
                    continue;
                }else if(charArray[i] == '%' && charArray[i + 1] == 'd'){
                    i += 2;
                    Exp paramExp = expList.get(expIndex ++);
                    expRec(paramExp);
                    ArrayList<Parameter> putchParams = new ArrayList<>();
                    Parameter parameter = new Parameter("i32", middleVal.copy());
                    putchParams.add(parameter);
                    insFactory.generateCall(curBasicBlock, "void", "@putint", putchParams);
                }else{
                    ArrayList<Parameter> putchParams = new ArrayList<>();
                    middleVal.setIntCon(charArray[i]);
                    Parameter parameter = new Parameter("i32", middleVal.copy());
                    putchParams.add(parameter);
                    insFactory.generateCall(curBasicBlock, "void", "@putch", putchParams);
                }
            }
        }
    }
    private void condRec(){
        // // Cond → LOrExp

    }
    private void lOrExpRec(){
        // LOrExp → LAndExp { '||' LAndExp }

    }
    private void lAndExpRec(){
        // LAndExp → EqExp { '&&' EqExp }
    }
    private void eqExpRec(){
        // EqExp → RelExp { ('==' | '!=') RelExp }
    }
    private void relExpRec(){
        // RelExp → AddExp { ('<' | '>' | '<=' | '>=') AddExp }
    }
    private void forStmtRec(){
        // // ForStmt → LVal '=' Exp
    }
    private void funcFParamsRec(FuncFParams funcFParams){
        // FuncFParams → FuncFParam { ',' FuncFParam }
        ArrayList<FuncFParam> funcFParamList = funcFParams.getFuncFParamList();
        for(FuncFParam funcFParam: funcFParamList){
            funcFParamRec(funcFParam);
        }
        curFuncFParamList = funcFParamList;
    }
    private void funcFParamRec(FuncFParam funcFParam){
        // FuncFParam → BType Ident ['[' ']' { '[' ConstExp ']' }]
        Word ident = funcFParam.getIdent();
        int dimension = funcFParam.getDimension();
        if(dimension == 0){ // 普通变量 "i32"
            String regName = insFactory.getParameterRegister();
            funcFParam.setValue(new MiddleVal("register", 0, regName, null));
        }else if(dimension == 1){ // 一维数组 "i32*"

        }
    }
    private void mainFuncDefRec(MainFuncDef mainFuncDef){
        //  MainFuncDef → 'int' 'main' '(' ')' Block
        Block block = mainFuncDef.getBlock();
        declareFunc("@main", false, 0, new ArrayList<>());
        curBasicBlock = new BasicBlock(); // 函数起始的基本块
        curBasicBlockList.add(curBasicBlock);
        blockRec(block);
        FuncSymbol main = (FuncSymbol) symTab.getTable().get("@main");
        String retType = main.voidFunc()?"void":"i32";
        Function mainFunc = insFactory.generateFunction("@main", retType, new ArrayList<>(), curBasicBlockList);
        curBasicBlockList.clear(); // 清空，为下一个函数做准备
        out.addFunction(mainFunc);
    }

    //符号表相关
    private void createSymTab(){ // 创建符号表
        symTab = new SymbolTable(symTab);
    }
    private void exitSymTab(){
        symTab = symTab.getParent();
    }
    private boolean symHadDeclared(String token){ // 符号已声明，在当前符号表中已存在token相同的符号
        for (String key:symTab.getTable().keySet()){ // 遍历符号表
            if(symTab.getTable().get(key).getToken().equals(token)){
                return true;
            }
        }
        return false;
    }
    public VarSymbol declareVar(String token, int dimension, ArrayList<Integer> length, boolean isConst, MiddleVal middleVal){ // 声明符号：填表
        VarSymbol vs = new VarSymbol(token, symTab.getLayer(), dimension, length, isConst, middleVal);
        symTab.getTable().put(token,vs);
        return vs;
    }
    public FuncSymbol declareFunc(String token, boolean isVoidFunc, int paramNum, ArrayList<Integer> dimensions){
        FuncSymbol fs = new FuncSymbol(token, symTab.getLayer(), isVoidFunc, paramNum, dimensions);
        symTab.getTable().put(token,fs);
        return fs;
    }
    public Symbol searchSymbol(String token){ // 从当前层开始逐层寻找符号，若存在（本层或外层声明过）则返回
        SymbolTable symbolTable = symTab; // 当前层
        while(symbolTable != null && symbolTable.getLayer() >= 0){
            for (String key:symbolTable.getTable().keySet()){ // 遍历符号表
                if(symbolTable.getTable().get(key).getToken().equals(token)){
                    return symbolTable.getTable().get(key); // 找到后立刻返回：取最靠近内层的变量声明
                }
            }
            symbolTable = symbolTable.getParent();
        }
        return null;
    }

}
