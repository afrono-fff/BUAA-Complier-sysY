package LlvmGenerate.Registers;

import SymbolTable.Symbol;

public class Register {
    String name;
    Symbol symbol;
    public Register(String name, Symbol symbol){
        this.name = name;
        this.symbol = symbol;
    }
}
