package LlvmGenerate.Registers;

import java.util.ArrayList;
import java.util.Stack;

public class RegisterPool {
    private Stack<String> pool;
    public RegisterPool(){
        pool = new Stack<>();
        for(int i = 1000; i >= 0; i--){
            pool.push("%r"+i);
        }
    }
    public String distributeRegister(){
        return pool.pop();
    }
}
