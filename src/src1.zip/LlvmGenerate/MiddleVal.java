package LlvmGenerate;

import LlvmGenerate.Instructions.Instruction;

public class MiddleVal {
    private String type; // intConst  register  instruction
    private int intCon;
    private String register;
    private Instruction instruction;
    public MiddleVal(){}
    public MiddleVal(String type, int intCon, String register, Instruction instruction){
        this.type = type;
        this.intCon = intCon;
        this.register = register;
        this.instruction = instruction;
    }

    public int getIntCon() {
        return intCon;
    }

    public Instruction getInstruction() {
        return instruction;
    }

    public String getRegister() {
        return register;
    }

    public String getType() {
        return type;
    }

    public void setIntCon(int intCon) {
        this.type = "intConst";
        this.intCon = intCon;
    }

    public void setRegister(String register) {
        this.type = "register";
        this.register = register;
    }

    public void setInstruction(Instruction instruction) {
        this.type = "instruction";
        this.instruction = instruction;
    }

    public void setType(String type) {
        this.type = type;
    }

    public MiddleVal copy(){
        return new MiddleVal(this.type, this.intCon, this.register, this.instruction);
    }
    @Override
    public String toString() {
        if(type.equals("intConst")){
            return intCon+"";
        }else if(type.equals("register")){
            return register;
        }else if(type.equals("instruction")){
            return instruction.toString();
        }
        return null;
    }
}
