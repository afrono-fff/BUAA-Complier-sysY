package LlvmGenerate;

public class Operand {
}
